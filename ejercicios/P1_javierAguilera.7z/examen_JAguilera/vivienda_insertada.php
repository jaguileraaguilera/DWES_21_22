<?php

echo "<h1>Inserción de vivienda</h1>";
echo "Estos son los datos introducidos:";
