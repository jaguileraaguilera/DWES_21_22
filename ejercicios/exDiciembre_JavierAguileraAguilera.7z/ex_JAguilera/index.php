<?php require_once '/conexion.php'; ?>

<!DOCTYPE html>
  <html>
      <head>
        <meta charset='utf-8'>
        <meta http-equiv='X-UA-Compatible' content='IE=edge'>
        <title>Page Title</title>
        <meta name='viewport' content='width=device-width, initial-scale=1'>
      </head>
  <body>
      <h1>Rutas senderismo</h1>
      
      <a href="agregarRuta.php">Nueva Ruta</a>
      <table>
          <tr>
              <td>Título</td>
              <td>Descripción</td>
              <td>Desnivel (m)</td>
              <td>Distancia (Km)</td>
              <td>Dificultad</td>
              <td>Operaciones</td>
          </tr>
          <tr>
              <td>
                  <?php ?>
              </td>
          </tr>
      </table>
  </body>
</html>

<?php
