<?php

session_start();
require_once __DIR__."/requires/cabecera.php";
require_once __DIR__."/requires/lateral.php";
require_once __DIR__."/requires/cuerpo.php";
require_once __DIR__."/requires/pie.php";

//print_r($_SESSION);