<section>
    <h2>Últimas entradas</h2>
    <article>
        <h3>Título de mi entrada</h3>
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Eos quisquam mollitia expedita ipsum! Maxime quibusdam tenetur error numquam architecto? Dolorum sint minima minus nam iure! Quidem labore animi unde laudantium!</p>
    </article>
</section>

